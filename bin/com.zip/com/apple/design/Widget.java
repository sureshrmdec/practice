package com.apple.design;

import java.util.Observable;

public abstract class Widget extends Observable {

	
}
