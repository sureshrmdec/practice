package com.apple.design;

public class Indigo extends Widget implements Shakeable {

	@Override
	public int shake() {
		// TODO Auto-generated method stub
		return 0;
	}

}
