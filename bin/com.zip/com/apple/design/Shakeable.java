package com.apple.design;

public interface Shakeable {

	public int shake();
}
