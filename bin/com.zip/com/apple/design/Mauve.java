package com.apple.design;

public class Mauve extends Widget implements Draggable {


	@Override
	public int drag() {
		// TODO Auto-generated method stub
		return 0;
	}

}
