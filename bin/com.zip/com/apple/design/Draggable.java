package com.apple.design;

public interface Draggable{
	
	public int drag();

}
