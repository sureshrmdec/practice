package com.apple.design;

public class Tan extends Widget implements Shakeable,Draggable {

	@Override
	public int drag() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int shake() {
		// TODO Auto-generated method stub
		return 0;
	}

}
