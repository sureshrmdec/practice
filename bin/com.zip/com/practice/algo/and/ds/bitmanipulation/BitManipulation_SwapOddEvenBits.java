package com.practice.algo.and.ds.bitmanipulation;


//http://www.geeksforgeeks.org/swap-all-odd-and-even-bits/

public class BitManipulation_SwapOddEvenBits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
