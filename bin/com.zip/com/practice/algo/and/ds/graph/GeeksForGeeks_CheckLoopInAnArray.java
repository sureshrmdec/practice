package com.practice.algo.and.ds.graph;

import java.util.HashSet;

//http://www.geeksforgeeks.org/check-loop-array-according-given-constraints/
public class GeeksForGeeks_CheckLoopInAnArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer[] arr = {2, -1, 1, 2, 2};
		GeeksForGeeks_CheckLoopInAnArray o = new GeeksForGeeks_CheckLoopInAnArray();
		o.checkLoop(arr);
	}

	private void checkLoop(Integer[] arr) {
		// TODO Auto-generated method stub
		HashSet<Integer> indexes = new HashSet<>();
		
		
		
	}

}
