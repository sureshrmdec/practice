package com.practice.algo.and.ds.graph;

public class Graphs_Bloomberg_ALU {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
//Multiply by 2 division by 3.
	//Start with 1...and keep adding states...eg 1*2 and 1/3
}
