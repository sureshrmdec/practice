package com.practice.algo.and.ds.interview.questions;

//{-5, -2, 5, 2, 4, 7, 1, 8, 0, -8}
//http://www.geeksforgeeks.org/rearrange-array-alternating-positive-negative-items-o1-extra-space/
//Another important/interesting question
//http://www.geeksforgeeks.org/anagram-substring-search-search-permutations/

public class GeeksForGeeks_ZigZagNegativePositive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {-5, -2, 5, 2, 4, 7, 1, 8, 0, -8};
	}

	public void reArrange(int[] a){
		
	}
}
