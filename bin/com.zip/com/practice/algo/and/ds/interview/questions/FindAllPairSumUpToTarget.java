package com.practice.algo.and.ds.interview.questions;

import java.util.Arrays;

public class FindAllPairSumUpToTarget {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Integer[] a = {2,45,7,3,5,1,8,9};
		printSumPairs(a,10);
	}

	private static void printSumPairs(Integer[] a, int i) {
		// TODO Auto-generated method stub
		Arrays.sort(a);
		
	}

}
