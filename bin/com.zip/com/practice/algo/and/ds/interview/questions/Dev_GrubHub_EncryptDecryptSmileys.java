package com.practice.algo.and.ds.interview.questions;

import java.util.HashMap;
import java.util.Map;

public class Dev_GrubHub_EncryptDecryptSmileys {

	public static void main(String[] args) {
		buildMap();
		Dev_GrubHub_EncryptDecryptSmileys o = new Dev_GrubHub_EncryptDecryptSmileys();
		
		o.decrypt(o.encrypt("cccsdsdsfvdfvtrbrtbybtabc"));

	}
	private static Map<Character,String> mapKV = new HashMap<Character,String>();
	private static Map<String,Character> mapVK = new HashMap<String,Character>();


	public String encrypt(String input){
		StringBuilder result  = new StringBuilder();
		char[] cA = input.toCharArray();
		for(char c:cA){
			result.append(mapKV.get(c));
		}
		System.out.println(result.toString());
		return result.toString();
	}

	public void decrypt(String input){
		String result = "";
		for(int i=0;i<input.length();i=i+6){
			result+=mapVK.get(input.substring(i, i+6));
		}
		System.out.println(result);
		
	}

	private static void buildMap(){

		char a = 'a';
		
		int v = 0;
		for(int i = 0;i<26;i++){
			v = v + 1;
			String binaryString = Integer.toBinaryString(v);
			int lenOfBinaryString = binaryString.length();
			while(lenOfBinaryString<6){
				binaryString = "0"+binaryString;
				lenOfBinaryString++;
			}
			mapKV.put((char)(a+i), binaryString);
			mapVK.put(binaryString, (char)(a+i));
		}
		a = 'A';

		for(int i = 0;i<26;i++){
			v = v + 1;
			String binaryString = Integer.toBinaryString(v);
			int lenOfBinaryString = binaryString.length();
			while(lenOfBinaryString<6){
				binaryString = "0"+binaryString;
				lenOfBinaryString++;
			}
			mapKV.put((char)(a+i), binaryString);
			mapVK.put(binaryString, (char)(a+i));
		}
	}
}
