package com.practice.algo.and.ds.interview.questions;

//https://www.careercup.com/question?id=13167666

public class CareerCup_Amazon_CelebrityProblem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
