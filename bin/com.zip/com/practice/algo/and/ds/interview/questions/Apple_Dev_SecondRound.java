package com.practice.algo.and.ds.interview.questions;

public class Apple_Dev_SecondRound {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
