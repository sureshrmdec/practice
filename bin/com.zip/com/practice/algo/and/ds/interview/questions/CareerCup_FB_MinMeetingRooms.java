package com.practice.algo.and.ds.interview.questions;

//https://www.careercup.com/question?id=6277103186083840

/*- Put all numbers in a simple array but the end time with a negative sign
- Sort the array by the absolute value of elements
- Do a simple for loop, keeping a current value of number of currently scheduled meetings; if the current number is positive - increase it by 1, otherwise - decrease by 1
- Keep track of its maximum value - that's the answer
*/
public class CareerCup_FB_MinMeetingRooms {

	public static void main(String[] args) {
		
	}
}
