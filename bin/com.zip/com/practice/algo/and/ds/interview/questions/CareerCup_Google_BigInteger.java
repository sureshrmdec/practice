package com.practice.algo.and.ds.interview.questions;

import java.math.BigInteger;

public class CareerCup_Google_BigInteger {

	public static void main(String[] args) {
		BigInteger bi = new BigInteger("10000000000");
		byte[] ba = bi.toByteArray();
		
		bi.add(BigInteger.ONE);
		System.out.println(5>>>1);
	}
}
