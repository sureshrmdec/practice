package com.practice.algo.and.ds.interview.questions;



//http://www.geeksforgeeks.org/design-a-data-structure-that-supports-insert-delete-search-and-getrandom-in-constant-time/

public class LeetCode_InsertionDeletionRandomInO1 {


}
