package com.practice.algo.and.ds.disjointdataset;

public class DisJointDataStructure {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	static class ListNode{
		ListNode head;
		ListNode tail;
		ListNode next;
		
		
		
	}
}
