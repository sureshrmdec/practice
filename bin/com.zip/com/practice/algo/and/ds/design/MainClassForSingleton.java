package com.practice.algo.and.ds.design;

public class MainClassForSingleton {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Singleton s = Singleton.getInstance();
		System.out.println(s);
		
	}

}
