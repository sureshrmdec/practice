package com.practice.algo.and.ds.dp;

/*
     nums = [
        [9,9,4],
        [6,6,8],
        [2,1,1]
         ]
	 
	 nums = [
	  [3,4,5],
	  [3,2,6],
	  [2,2,1]
		]     
     
 */
    		  
public class DP_LeetCode_LongestPathInMatrix {
	
	public static void main(String[] args) {
		
	}
    public int longestIncreasingPath(int[][] matrix) {
        int result = 0;
        
        return result;
    }
}
