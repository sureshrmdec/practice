package com.practice.algo.and.ds.dp;

import java.math.BigInteger;

public class HackerRank_GridWalking {

	public static void main(String[] args) {
		BigInteger result = BigInteger.valueOf(2);
		System.out.println(result.pow(287).mod(BigInteger.valueOf(1000000007)));
		System.out.println(Math.pow(2, 287)%1000000007);
	}
}
